const $ = id => document.getElementById(id);
const state = {node:'p1', affection:0, courage:0, trust:0, route:'', log:[], auto:false, skip:false, ended:false};
const nodes = {
 p1:{chapter:'PROLOGUE · 봄날의 학생회',bg:'school',who:'나',sprite:'me',text:'고등학교 2학년 봄. 용기를 내어 들어온 학생회에서, 나는 오래 짝사랑해 온 류권우 선배와 같은 업무를 맡게 됐다.',next:'p2'},
 p2:{chapter:'PROLOGUE · 봄날의 학생회',bg:'school',who:'류권우',sprite:'queen',text:'“신입 부원 맞지? 자료 정리는 내가 도와줄게. 처음엔 헷갈리는 게 당연하니까 너무 긴장하지 마.” 선배는 내 이름을 기억하고 있었다.',next:'p3'},
 p3:{chapter:'PROLOGUE · 봄날의 학생회',bg:'school',who:'나',sprite:'me',text:'다정하고 세심한 배려. 선배가 웃을 때마다 마음이 간질거렸다. 이 사람에게 잘 보이고 싶다는 생각이 커졌다.',choices:[['조금 더 가까워지고 싶다고 솔직히 말한다','p4a',{affection:1}],['학생회 일에 집중하며 천천히 알아간다','p4b',{trust:1}]]},
 p4a:{chapter:'PROLOGUE · 봄날의 학생회',bg:'school',who:'류권우',sprite:'queen',text:'“하하, 그럼 앞으로 같이 열심히 해 보자.” 선배는 환하게 웃었다. 나는 그 미소를 오래 기억하고 싶었다.',next:'c1'},
 p4b:{chapter:'PROLOGUE · 봄날의 학생회',bg:'school',who:'류권우',sprite:'queen',text:'“일을 꼼꼼하게 하네. 믿음직한데?” 선배의 칭찬에 어깨가 조금 펴졌다. 마음은 서두르지 않아도 괜찮을지 모른다.',next:'c1'},
 c1:{chapter:'CHAPTER 1 · 달콤한 얼굴을 한 유혹',bg:'classroom',who:'나',sprite:'me',text:'중간고사 기간. 며칠째 잠을 줄여 공부한 탓에 눈꺼풀이 무거웠다. 늦은 오후, 학생회실에 선배가 들어왔다.',next:'c2'},
 c2:{chapter:'CHAPTER 1 · 달콤한 얼굴을 한 유혹',bg:'classroom',who:'류권우',sprite:'queen',text:'“요즘 많이 피곤하지? 이거 나만 아는 특별한 영양제인데, 한 번 먹어 볼래? 집중도 잘되고 효과 엄청 좋아.”',next:'c3'},
 c3:{chapter:'CHAPTER 2 · 선택의 기로',bg:'classroom',who:'나',sprite:'me',text:'선배가 내민 것은 성분과 출처를 알 수 없는 알약이었다. 좋아하는 사람이 건넨 호의라 해도, 정체를 모르는 약을 먹어도 괜찮을까?',choices:[['선배를 실망시키고 싶지 않아 일단 받는다','bad1',{affection:1,route:'unsafe'}],['고맙지만 성분을 모르니 먹지 않겠다고 말한다','g1',{courage:1,trust:1,route:'safe'}]]},
 bad1:{chapter:'CHAPTER 2 · 선택의 기로',bg:'classroom',who:'나',sprite:'me',text:'“선배가 추천하는 거니까….” 나는 불안한 마음을 숨긴 채 받아 버렸다. 누군가의 호감을 지키려고 내 안전을 양보한 순간이었다.',next:'bad2'},
 bad2:{chapter:'CHAPTER 2 · 선택의 기로',bg:'sunset',who:'나',sprite:'me',text:'그 뒤로 나는 점점 불안해졌고, 선배와의 관계도 예전 같지 않았다. 정체를 모르는 약은 내 몸과 마음을 위험에 빠뜨릴 수 있었다. 호의처럼 보이는 권유라도 안전을 먼저 지켜야 했다.',next:'badend'},
 g1:{chapter:'CHAPTER 2 · 거절의 기술 1/3',bg:'classroom',who:'나',sprite:'me',text:'“고마워요, 선배. 그런데 저는 이런 캔디나 영양제는 먹지 않아요.” 목소리는 작았지만, 내 선택을 처음으로 분명히 말했다.',next:'g2'},
 g2:{chapter:'CHAPTER 2 · 거절의 기술 2/3',bg:'classroom',who:'류권우',sprite:'queen',text:'“그냥 영양제라니까? 너무 걱정하지 않아도 돼.” 선배는 가볍게 웃었지만, 나는 여전히 성분을 알 수 없다는 점이 마음에 걸렸다.',choices:[['성분과 출처를 확인할 수 없는 건 먹을 수 없어요','g3',{courage:1,trust:1}],['선배가 괜찮다고 했으니 이번만 믿어 본다','bad1',{affection:1,route:'unsafe'}]]},
 g3:{chapter:'CHAPTER 2 · 거절의 기술 3/3',bg:'classroom',who:'나',sprite:'me',text:'“성분이 정확히 뭔지 모르는 건 먹을 수 없어요. 제 건강이 걸린 일이니까요.” 심장이 두근거렸지만, 이유를 분명하게 말하자 생각이 또렷해졌다.',next:'g4'},
 g4:{chapter:'CHAPTER 2 · 단호한 철벽',bg:'classroom',who:'류권우',sprite:'queen',text:'“그 정도로 말할 일인가? 다들 괜찮다고 하던데….” 선배의 표정이 굳었다. 그래도 내 안전을 포기할 이유는 없었다.',choices:[['선배, 이런 수상한 걸 권하는 건 불쾌해요. 다시는 주지 마세요.','g5',{courage:2,trust:1,route:'safe'}],['불편하지만 웃으며 화제를 돌린다','gsoft',{courage:0,trust:0,route:'soft'}]]},
 gsoft:{chapter:'CHAPTER 2 · 흔들리는 마음',bg:'classroom',who:'나',sprite:'me',text:'나는 웃으며 화제를 돌렸지만, 선배는 약을 치우지 않았다. 거절 의사는 분명하게 전하고, 위험한 상황이라면 자리를 벗어나 믿을 만한 어른에게 도움을 요청해야 한다.',choices:[['이번에는 분명하게 선을 긋는다','g5',{courage:2,trust:1,route:'safe'}],['더 이상 말하지 않고 혼자 자리를 떠난다','n1',{courage:1,route:'soft'}]]},
 g5:{chapter:'CHAPTER 2 · 단호한 철벽',bg:'sunset',who:'나',sprite:'me',text:'“선배, 이런 수상한 걸 권하는 건 불쾌해요. 다시는 주지 마세요.” 내 목소리는 떨렸지만 말은 분명했다. 상대가 누구든, 내 몸과 안전에 관한 결정은 내가 한다.',next:'c1x'},
 c1x:{chapter:'CHAPTER 3 · 철벽이 쏘아 올린 기적',bg:'sunset',who:'류권우',sprite:'queen',text:'선배는 한동안 아무 말도 하지 못했다. “사실… 나도 성적 때문에 너무 불안했어. 나쁜 친구들이 이걸 권했고, 별일 아니라고 생각했어. 다른 사람에게까지 권한 건 잘못이야.”',next:'c2x'},
 c2x:{chapter:'CHAPTER 3 · 철벽이 쏘아 올린 기적',bg:'counsel',who:'나',sprite:'me',text:'선배의 사정이 잘못을 없애 주지는 않는다. 하지만 지금이라도 멈추고 도움을 구할 수는 있다. 혼자 해결하려 하지 말고, 믿을 수 있는 어른과 전문기관에 알려야 한다.',choices:[['선생님께 함께 알리고 도움을 받자고 제안한다','true1',{trust:2,courage:1}],['선배가 직접 책임지고 상담을 요청하도록 권한다','true2',{trust:1,courage:1}]]},
 true1:{chapter:'EPILOGUE · 진짜 연애는 철벽 뒤에',bg:'counsel',who:'류권우',sprite:'queen',text:'“그래. 내가 한 일을 숨기지 않을게. 선생님께 말씀드리고 도움을 받을게.” 선배는 학교의 믿을 만한 어른에게 사실을 알리고, 위험한 무리와 거리를 두기로 했다.',next:'trueend'},
 true2:{chapter:'EPILOGUE · 진짜 연애는 철벽 뒤에',bg:'counsel',who:'류권우',sprite:'queen',text:'“내가 직접 말씀드릴게. 더는 숨기지 않을 거야.” 선배는 상담을 요청하고, 자신이 했던 행동을 바로잡기 위한 도움을 받기로 했다.',next:'trueend'},
 n1:{chapter:'EPILOGUE · 남겨진 용기',bg:'sunset',who:'나',sprite:'me',text:'나는 그 자리를 벗어나 믿을 수 있는 어른에게 상황을 알렸다. 선배의 마음을 내가 책임질 필요는 없다. 안전을 지키는 선택은 언제나 괜찮다.',next:'normalend'},
 badend:{ending:'bad',title:'호의라는 이름의 위험',text:'누군가의 마음을 잃을까 봐 내 안전을 양보하면 안 된다. 정체를 알 수 없는 약은 받거나 먹지 말고, 상황을 믿을 수 있는 어른에게 알려 도움을 요청하자.'},
 normalend:{ending:'normal',title:'내 마음을 지킨 하루',text:'완벽한 대답을 바로 하지 못했더라도 괜찮다. 위험한 상황에서 벗어나고 믿을 수 있는 어른에게 도움을 요청한 것은 용기 있는 선택이다.'},
 trueend:{ending:'true',title:'진짜 연애는 철벽 뒤에',text:'“네 단호한 철벽이 날 구했어. 미안하고 고마워.” 선배는 자신의 잘못을 인정하고 도움을 받기 시작했다. 사과만으로 모든 일이 사라지지는 않지만, 책임지는 행동은 변화의 시작이 될 수 있다. 두 사람은 서두르지 않고 서로를 존중하는 관계를 다시 알아가기로 했다.'}
};
let current = null;
function save(){try{localStorage.setItem('cheolbyeok-save',JSON.stringify({state,nodesNode:state.node}));}catch(e){}}
function load(){try{return JSON.parse(localStorage.getItem('cheolbyeok-save')||'null')}catch(e){return null}}
function setBG(bg){$('background').className='background '+(bg||'student_council')}
function showSprite(sprite,who){
 const el=$('sprite'), item=$('itemArt');
 el.classList.add('hidden-sprite');
 // 주인공 '나'는 화면에 그리지 않고 대사와 1인칭 시점으로만 표현
 if(!sprite || sprite==='me' || who==='나') { item.classList.toggle('hidden', !(current && ['c2','c3','g2','g4','bad1'].includes(state.node))); return; }
 const t=(current&&current.text)||''; let mood='calm';
 if(/건네|내민|먹어 볼래|특별한 영양제/.test(t) || state.node==='c2') mood='offer';
 else if(/환하게 웃|하하|고마워|미소/.test(t)) mood='smile';
 else if(/불쾌|불안|위험|굳었|떨렸|잘못|단호|다시는/.test(t)) mood='serious';
 else if(/미안|사과|도움|책임/.test(t)) mood='worried';
 else if(/믿음직|칭찬|좋아/.test(t)) mood='soft';
 $('characterImage').src='assets/character/'+mood+'.png';
 $('characterImage').alt='류권우 - '+({calm:'평온한 표정',offer:'권유하는 표정',smile:'미소',serious:'진지한 표정',worried:'걱정하는 표정',soft:'부드러운 표정'}[mood]||'표정');
 $('spriteCaption').textContent='류권우 선배'; el.classList.remove('hidden-sprite');
 item.classList.toggle('hidden', !(current && ['c2','c3','g2','g4','bad1'].includes(state.node)));
}
function render(id){const n=nodes[id];if(!n){endGame('normal');return}state.node=id;current=n;state.ended=false;$('titleScreen').classList.add('hidden');$('endingScreen').classList.add('hidden');$('dialogue').classList.remove('hidden');$('choices').classList.add('hidden');setBG(n.bg);showSprite(n.sprite,n.who);$('sceneLabel').textContent=n.chapter;$('speaker').textContent=n.who;$('dialogueText').textContent=n.text;$('progress').textContent=n.chapter.split(' · ')[0]+' · '+id.toUpperCase();state.log.push({who:n.who,text:n.text,chapter:n.chapter});save();if(n.ending){endGame(n.ending);return}if(n.choices){$('choices').innerHTML='';n.choices.forEach((c,i)=>{const b=document.createElement('button');b.className='choice';b.textContent=c[0];b.onclick=e=>{e.stopPropagation();choose(c)};$('choices').appendChild(b)});$('choices').classList.remove('hidden')} }
function choose(c){const [label,next,effect={}] = c;Object.entries(effect).forEach(([k,v])=>{if(k==='route')state.route=v;else state[k]=(state[k]||0)+v});state.log.push({who:'선택',text:label,chapter:current.chapter});render(next)}
function advance(){if(!current||state.ended)return;if(current.choices)return;if(current.next)render(current.next);else if(current.ending)endGame(current.ending);else endGame('normal')}
function endGame(type){state.ended=true;$('dialogue').classList.add('hidden');$('choices').classList.add('hidden');$('sprite').classList.add('hidden-sprite');$('endingScreen').classList.remove('hidden');const data=nodes[type==='true'?'trueend':type==='bad'?'badend':'normalend'];$('endingType').textContent=type==='true'?'♡ TRUE ENDING ♡':type==='bad'?'✦ BAD ENDING ✦':'✧ NORMAL ENDING ✧';$('endingIcon').textContent=type==='true'?'♡':type==='bad'?'…':'✧';$('endingTitle').textContent=data.title;$('endingText').textContent=data.text;save()}
function start(){Object.assign(state,{node:'p1',affection:0,courage:0,trust:0,route:'',log:[],auto:false,skip:false,ended:false});render('p1')}
function modal(title,html){$('modalTitle').textContent=title;$('modalBody').innerHTML=html;$('modal').classList.remove('hidden')}
$('startBtn').onclick=start;$('continueBtn').onclick=()=>{const s=load();if(s&&s.state){Object.assign(state,s.state);render(state.node)}else start()};$('restartBtn').onclick=start;$('titleBtn').onclick=()=>{$('endingScreen').classList.add('hidden');$('titleScreen').classList.remove('hidden');$('background').className='background';$('sprite').classList.add('hidden-sprite')};
$('dialogue').onclick=advance;document.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){if(!$('modal').classList.contains('hidden'))return;advance()}if(e.key==='Escape')$('modal').classList.add('hidden')});
$('statusBtn').onclick=()=>modal('관계 기록',`<div class="modal-content"><p>💗 선배와의 호감도 <b>${state.affection}</b></p><p>🛡️ 거절 용기 <b>${state.courage}</b></p><p>✧ 신뢰 <b>${state.trust}</b></p><p>현재 분기: <b>${state.route||'아직 결정되지 않음'}</b></p><small>수치는 선택의 결과를 기록합니다. 이야기의 안전한 결말은 단호한 거절과 도움 요청에 따라 열립니다.</small></div>`);
$('logBtn').onclick=()=>modal('대사 로그',`<ol class="log-list">${state.log.slice(-40).map(x=>`<li><b>${esc(x.who)}</b> — ${esc(x.text)}</li>`).join('')||'<li>아직 기록이 없습니다.</li>'}</ol>`);
$('settingsBtn').onclick=()=>modal('설정',`<div class="modal-content"><p>대사 진행은 화면을 클릭하거나 Enter 키를 누르세요.</p><label><input type="checkbox" id="autoToggle" ${state.auto?'checked':''}> 자동 진행 (대사 클릭 시 다음으로)</label><p><button class="secondary" id="clearSave">저장 데이터 지우기</button></p><small>이 게임은 브라우저의 로컬 저장 공간에 진행 상황을 저장합니다.</small></div>`);
$('closeModal').onclick=()=>$('modal').classList.add('hidden');$('modal').onclick=e=>{if(e.target===$('modal'))$('modal').classList.add('hidden')};
$('modalBody').onclick=e=>{if(e.target.id==='autoToggle')state.auto=e.target.checked;if(e.target.id==='clearSave'){localStorage.removeItem('cheolbyeok-save');modal('설정','<p>저장 데이터를 지웠습니다.</p>')}};
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
setBG('student_council'); const saved=load();if(saved){$('continueBtn').classList.remove('hidden')}else{$('continueBtn').classList.add('hidden')}
